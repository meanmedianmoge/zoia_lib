#!/usr/bin/python
# -*- coding: utf-8 -*-
__version__ = '0.1.7'
__status__ = 'Work in Progress'
__license__ = 'MIT'

__author__ = 'Johnny Chan'

__module_name__ = 'NodeGraphQt'
__url__ = 'https://github.com/jchanvfx/NodeGraphQt'
