def count(self, value):
    return self.count(value)


def index(self, value):
    return self.index(value)


# custom functions
def get(self, index):
    return self.__getitem__(index)
